-- Each upsert chooses the latest version of each resource ID across staged FHIR Bundles.
CREATE OR ALTER PROCEDURE silver.usp_Upsert_Patient
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH src AS (
  SELECT JSON_VALUE(e.value,'$.resource.id') AS patient_id,
   JSON_VALUE(e.value,'$.resource.name[0].family') AS family_name,
   JSON_VALUE(e.value,'$.resource.name[0].given[0]') AS given_name,
   JSON_VALUE(e.value,'$.resource.gender') AS gender,
   TRY_CONVERT(DATE,JSON_VALUE(e.value,'$.resource.birthDate')) AS birth_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) AS last_updated,
   ROW_NUMBER() OVER(PARTITION BY JSON_VALUE(e.value,'$.resource.id')
    ORDER BY TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) DESC,r.staging_id DESC) AS rn
  FROM staging.fhir_raw r CROSS APPLY OPENJSON(r.raw_json,'$.entry') e
  WHERE r.resource_type='Patient'
 )
 MERGE silver.Patient AS t
 USING (SELECT * FROM src WHERE rn=1 AND patient_id IS NOT NULL) AS s ON t.patient_id=s.patient_id
 WHEN MATCHED AND EXISTS (SELECT s.family_name,s.given_name,s.gender,s.birth_date,s.last_updated
                          EXCEPT SELECT t.family_name,t.given_name,t.gender,t.birth_date,t.last_updated)
 THEN UPDATE SET family_name=s.family_name,given_name=s.given_name,gender=s.gender,
                 birth_date=s.birth_date,last_updated=s.last_updated
 WHEN NOT MATCHED THEN INSERT(patient_id,family_name,given_name,gender,birth_date,last_updated)
 VALUES(s.patient_id,s.family_name,s.given_name,s.gender,s.birth_date,s.last_updated);
END;
GO
CREATE OR ALTER PROCEDURE silver.usp_Upsert_Encounter
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH src AS (
  SELECT JSON_VALUE(e.value,'$.resource.id') AS encounter_id,
   REPLACE(JSON_VALUE(e.value,'$.resource.subject.reference'),'Patient/','') AS patient_id,
   JSON_VALUE(e.value,'$.resource.status') AS status,
   JSON_VALUE(e.value,'$.resource.class.code') AS encounter_class,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.period.start')) AS start_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.period.end')) AS end_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) AS last_updated,
   ROW_NUMBER() OVER(PARTITION BY JSON_VALUE(e.value,'$.resource.id')
    ORDER BY TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) DESC,r.staging_id DESC) AS rn
  FROM staging.fhir_raw r CROSS APPLY OPENJSON(r.raw_json,'$.entry') e WHERE r.resource_type='Encounter'
 )
 MERGE silver.Encounter t USING (SELECT * FROM src WHERE rn=1 AND encounter_id IS NOT NULL) s
 ON t.encounter_id=s.encounter_id
 WHEN MATCHED AND EXISTS (SELECT s.patient_id,s.status,s.encounter_class,s.start_date,s.end_date,s.last_updated
                          EXCEPT SELECT t.patient_id,t.status,t.encounter_class,t.start_date,t.end_date,t.last_updated)
 THEN UPDATE SET patient_id=s.patient_id,status=s.status,encounter_class=s.encounter_class,
                 start_date=s.start_date,end_date=s.end_date,last_updated=s.last_updated
 WHEN NOT MATCHED THEN INSERT(encounter_id,patient_id,status,encounter_class,start_date,end_date,last_updated)
 VALUES(s.encounter_id,s.patient_id,s.status,s.encounter_class,s.start_date,s.end_date,s.last_updated);
END;
GO
CREATE OR ALTER PROCEDURE silver.usp_Upsert_Observation
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH src AS (
  SELECT JSON_VALUE(e.value,'$.resource.id') AS observation_id,
   REPLACE(JSON_VALUE(e.value,'$.resource.subject.reference'),'Patient/','') AS patient_id,
   REPLACE(JSON_VALUE(e.value,'$.resource.encounter.reference'),'Encounter/','') AS encounter_id,
   JSON_VALUE(e.value,'$.resource.status') AS status,
   JSON_VALUE(e.value,'$.resource.code.coding[0].code') AS observation_code,
   COALESCE(JSON_VALUE(e.value,'$.resource.code.text'),JSON_VALUE(e.value,'$.resource.code.coding[0].display')) AS observation_name,
   COALESCE(JSON_VALUE(e.value,'$.resource.valueQuantity.value'),JSON_VALUE(e.value,'$.resource.valueString'),
            JSON_VALUE(e.value,'$.resource.valueCodeableConcept.text')) AS observation_value,
   COALESCE(JSON_VALUE(e.value,'$.resource.valueQuantity.unit'),JSON_VALUE(e.value,'$.resource.valueQuantity.code')) AS observation_unit,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.effectiveDateTime')) AS effective_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) AS last_updated,
   ROW_NUMBER() OVER(PARTITION BY JSON_VALUE(e.value,'$.resource.id')
    ORDER BY TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) DESC,r.staging_id DESC) AS rn
  FROM staging.fhir_raw r CROSS APPLY OPENJSON(r.raw_json,'$.entry') e WHERE r.resource_type='Observation'
 )
 MERGE silver.Observation t USING (SELECT * FROM src WHERE rn=1 AND observation_id IS NOT NULL) s
 ON t.observation_id=s.observation_id
 WHEN MATCHED AND EXISTS (SELECT s.patient_id,s.encounter_id,s.status,s.observation_code,s.observation_name,
  s.observation_value,s.observation_unit,s.effective_date,s.last_updated
  EXCEPT SELECT t.patient_id,t.encounter_id,t.status,t.observation_code,t.observation_name,
  t.observation_value,t.observation_unit,t.effective_date,t.last_updated)
 THEN UPDATE SET patient_id=s.patient_id,encounter_id=s.encounter_id,status=s.status,
  observation_code=s.observation_code,observation_name=s.observation_name,
  observation_value=s.observation_value,observation_unit=s.observation_unit,
  effective_date=s.effective_date,last_updated=s.last_updated
 WHEN NOT MATCHED THEN INSERT(observation_id,patient_id,encounter_id,status,observation_code,
  observation_name,observation_value,observation_unit,effective_date,last_updated)
 VALUES(s.observation_id,s.patient_id,s.encounter_id,s.status,s.observation_code,
  s.observation_name,s.observation_value,s.observation_unit,s.effective_date,s.last_updated);
END;
GO
CREATE OR ALTER PROCEDURE silver.usp_Upsert_Condition
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH src AS (
  SELECT JSON_VALUE(e.value,'$.resource.id') AS condition_id,
   REPLACE(JSON_VALUE(e.value,'$.resource.subject.reference'),'Patient/','') AS patient_id,
   REPLACE(JSON_VALUE(e.value,'$.resource.encounter.reference'),'Encounter/','') AS encounter_id,
   JSON_VALUE(e.value,'$.resource.clinicalStatus.coding[0].code') AS clinical_status,
   JSON_VALUE(e.value,'$.resource.code.coding[0].code') AS condition_code,
   COALESCE(JSON_VALUE(e.value,'$.resource.code.text'),JSON_VALUE(e.value,'$.resource.code.coding[0].display')) AS condition_name,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.onsetDateTime')) AS onset_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.recordedDate')) AS recorded_date,
   TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) AS last_updated,
   ROW_NUMBER() OVER(PARTITION BY JSON_VALUE(e.value,'$.resource.id')
    ORDER BY TRY_CONVERT(DATETIME2,JSON_VALUE(e.value,'$.resource.meta.lastUpdated')) DESC,r.staging_id DESC) AS rn
  FROM staging.fhir_raw r CROSS APPLY OPENJSON(r.raw_json,'$.entry') e WHERE r.resource_type='Condition'
 )
 MERGE silver.Condition t USING (SELECT * FROM src WHERE rn=1 AND condition_id IS NOT NULL) s
 ON t.condition_id=s.condition_id
 WHEN MATCHED AND EXISTS (SELECT s.patient_id,s.encounter_id,s.clinical_status,s.condition_code,s.condition_name,
  s.onset_date,s.recorded_date,s.last_updated
  EXCEPT SELECT t.patient_id,t.encounter_id,t.clinical_status,t.condition_code,t.condition_name,
  t.onset_date,t.recorded_date,t.last_updated)
 THEN UPDATE SET patient_id=s.patient_id,encounter_id=s.encounter_id,clinical_status=s.clinical_status,
  condition_code=s.condition_code,condition_name=s.condition_name,onset_date=s.onset_date,
  recorded_date=s.recorded_date,last_updated=s.last_updated
 WHEN NOT MATCHED THEN INSERT(condition_id,patient_id,encounter_id,clinical_status,condition_code,
  condition_name,onset_date,recorded_date,last_updated)
 VALUES(s.condition_id,s.patient_id,s.encounter_id,s.clinical_status,s.condition_code,
  s.condition_name,s.onset_date,s.recorded_date,s.last_updated);
END;
GO
