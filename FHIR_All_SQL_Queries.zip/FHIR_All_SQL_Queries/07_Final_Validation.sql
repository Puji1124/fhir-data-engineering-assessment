SELECT 'Patient' AS Resource,COUNT(*) AS Total FROM silver.Patient
UNION ALL SELECT 'Encounter',COUNT(*) FROM silver.Encounter
UNION ALL SELECT 'Observation',COUNT(*) FROM silver.Observation
UNION ALL SELECT 'Condition',COUNT(*) FROM silver.Condition;
SELECT resource_type,COUNT(*) AS staged_bundles FROM staging.fhir_raw GROUP BY resource_type;
SELECT resource_type,last_updated,last_run_time FROM control.fhir_watermark ORDER BY resource_type;
SELECT COUNT(*) AS history_rows,SUM(CASE WHEN is_current=1 THEN 1 ELSE 0 END) AS current_rows
FROM silver.Patient_History;
SELECT patient_id,COUNT(*) AS duplicate_count FROM silver.Patient GROUP BY patient_id HAVING COUNT(*)>1;
SELECT COUNT(*) AS patient_view_rows FROM dbo.vw_Patient_Summary;
SELECT COUNT(*) AS encounter_view_rows FROM dbo.vw_Encounter_Summary;
SELECT COUNT(*) AS observation_view_rows FROM dbo.vw_Observation_Summary;
SELECT COUNT(*) AS condition_view_rows FROM dbo.vw_Condition_Summary;
