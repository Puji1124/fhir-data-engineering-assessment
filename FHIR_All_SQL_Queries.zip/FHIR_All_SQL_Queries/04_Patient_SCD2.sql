-- Compare current Silver patient attributes with current history and maintain Type 2 versions.
-- This reconstructed implementation uses the processing time as the SCD effective timestamp.
CREATE OR ALTER PROCEDURE silver.usp_Patient_SCD2
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 BEGIN TRANSACTION;
 DECLARE @now DATETIME2 = SYSUTCDATETIME();
 UPDATE h SET effective_to=@now,is_current=0
 FROM silver.Patient_History h
 INNER JOIN silver.Patient p ON p.patient_id=h.patient_id
 WHERE h.is_current=1 AND EXISTS (
  SELECT p.family_name,p.given_name,p.gender,p.birth_date
  EXCEPT SELECT h.family_name,h.given_name,h.gender,h.birth_date
 );
 INSERT INTO silver.Patient_History(patient_id,family_name,given_name,gender,birth_date,effective_from,effective_to,is_current)
 SELECT p.patient_id,p.family_name,p.given_name,p.gender,p.birth_date,@now,NULL,1
 FROM silver.Patient p
 WHERE NOT EXISTS (SELECT 1 FROM silver.Patient_History h WHERE h.patient_id=p.patient_id AND h.is_current=1);
 COMMIT TRANSACTION;
END;
GO
