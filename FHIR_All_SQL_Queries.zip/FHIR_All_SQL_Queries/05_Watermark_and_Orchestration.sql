-- Updates watermark from maximum last_updated in the relevant Silver table.
-- WARNING: use only after ALL intended pages have been ingested and processed.
-- A page-limited demo should not advance a production incremental watermark.
CREATE OR ALTER PROCEDURE control.usp_Update_FHIR_Watermark @resource_type VARCHAR(50)
AS
BEGIN
 SET NOCOUNT ON;
 IF @resource_type NOT IN ('Patient','Encounter','Observation','Condition')
  THROW 50002,'Unsupported FHIR resource type',1;
 DECLARE @max_updated DATETIME2;
 SELECT @max_updated=MAX(last_updated) FROM (
  SELECT last_updated FROM silver.Patient WHERE @resource_type='Patient'
  UNION ALL SELECT last_updated FROM silver.Encounter WHERE @resource_type='Encounter'
  UNION ALL SELECT last_updated FROM silver.Observation WHERE @resource_type='Observation'
  UNION ALL SELECT last_updated FROM silver.Condition WHERE @resource_type='Condition'
 ) AS x;
 UPDATE control.fhir_watermark
 SET last_updated=CASE WHEN @max_updated IS NULL THEN last_updated
                       WHEN last_updated IS NULL OR @max_updated>last_updated THEN @max_updated
                       ELSE last_updated END,
     last_run_time=SYSUTCDATETIME()
 WHERE resource_type=@resource_type;
END;
GO
CREATE OR ALTER PROCEDURE silver.usp_Process_FHIR_Resource @resource_type VARCHAR(50)
AS
BEGIN
 SET NOCOUNT ON;
 IF @resource_type NOT IN ('Patient','Encounter','Observation','Condition')
  THROW 50003,'Unsupported FHIR resource type',1;
 IF @resource_type='Patient'
 BEGIN
  EXEC silver.usp_Upsert_Patient;
  EXEC silver.usp_Patient_SCD2;
 END;
 IF @resource_type='Encounter' EXEC silver.usp_Upsert_Encounter;
 IF @resource_type='Observation' EXEC silver.usp_Upsert_Observation;
 IF @resource_type='Condition' EXEC silver.usp_Upsert_Condition;
 EXEC control.usp_Update_FHIR_Watermark @resource_type=@resource_type;
END;
GO
