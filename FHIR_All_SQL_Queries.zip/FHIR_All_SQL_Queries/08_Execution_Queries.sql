-- Commands used to execute the Silver upsert procedures.
-- Do not run these again merely to prepare the submission.
EXEC silver.usp_Upsert_Encounter;
EXEC silver.usp_Upsert_Observation;
EXEC silver.usp_Upsert_Condition;
GO
-- Common resource processor used by ADF (sample manual invocation)
-- EXEC silver.usp_Process_FHIR_Resource @resource_type = 'Patient';
-- EXEC silver.usp_Process_FHIR_Resource @resource_type = 'Encounter';
-- EXEC silver.usp_Process_FHIR_Resource @resource_type = 'Observation';
-- EXEC silver.usp_Process_FHIR_Resource @resource_type = 'Condition';
-- SCD2 procedure used by ADF for Patient
-- EXEC silver.usp_Patient_SCD2;
