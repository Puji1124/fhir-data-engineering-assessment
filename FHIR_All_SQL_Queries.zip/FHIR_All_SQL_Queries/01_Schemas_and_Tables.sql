-- FHIR assessment: reconstructed DDL. Run on a new database only after reviewing against existing objects.
IF SCHEMA_ID('staging') IS NULL EXEC('CREATE SCHEMA staging');
IF SCHEMA_ID('silver') IS NULL EXEC('CREATE SCHEMA silver');
IF SCHEMA_ID('control') IS NULL EXEC('CREATE SCHEMA control');
GO
IF OBJECT_ID('staging.fhir_raw','U') IS NULL
CREATE TABLE staging.fhir_raw (
 staging_id BIGINT IDENTITY(1,1) PRIMARY KEY,
 resource_type VARCHAR(50) NOT NULL,
 raw_json NVARCHAR(MAX) NOT NULL,
 extraction_timestamp DATETIME2 DEFAULT SYSUTCDATETIME(),
 api_url_or_params NVARCHAR(2000), source_file NVARCHAR(1000), pipeline_run_id VARCHAR(100)
);
GO
IF OBJECT_ID('silver.Patient','U') IS NULL
CREATE TABLE silver.Patient (
 patient_id NVARCHAR(100) PRIMARY KEY, family_name NVARCHAR(200), given_name NVARCHAR(200),
 gender NVARCHAR(20), birth_date DATE, last_updated DATETIME2
);
IF OBJECT_ID('silver.Encounter','U') IS NULL
CREATE TABLE silver.Encounter (
 encounter_id NVARCHAR(100) PRIMARY KEY, patient_id NVARCHAR(100), status NVARCHAR(100),
 encounter_class NVARCHAR(100), start_date DATETIME2, end_date DATETIME2, last_updated DATETIME2
);
IF OBJECT_ID('silver.Observation','U') IS NULL
CREATE TABLE silver.Observation (
 observation_id NVARCHAR(100) PRIMARY KEY, patient_id NVARCHAR(100), encounter_id NVARCHAR(100),
 status NVARCHAR(100), observation_code NVARCHAR(200), observation_name NVARCHAR(1000),
 observation_value NVARCHAR(500), observation_unit NVARCHAR(200), effective_date DATETIME2,
 last_updated DATETIME2
);
IF OBJECT_ID('silver.Condition','U') IS NULL
CREATE TABLE silver.Condition (
 condition_id NVARCHAR(100) PRIMARY KEY, patient_id NVARCHAR(100), encounter_id NVARCHAR(100),
 clinical_status NVARCHAR(100), condition_code NVARCHAR(200), condition_name NVARCHAR(1000),
 onset_date DATETIME2, recorded_date DATETIME2, last_updated DATETIME2
);
IF OBJECT_ID('silver.Patient_History','U') IS NULL
CREATE TABLE silver.Patient_History (
 history_id BIGINT IDENTITY(1,1) PRIMARY KEY, patient_id NVARCHAR(100) NOT NULL,
 family_name NVARCHAR(200), given_name NVARCHAR(200), gender NVARCHAR(20), birth_date DATE,
 effective_from DATETIME2 NOT NULL, effective_to DATETIME2 NULL, is_current BIT NOT NULL
);
IF OBJECT_ID('control.fhir_watermark','U') IS NULL
CREATE TABLE control.fhir_watermark (
 resource_type VARCHAR(50) PRIMARY KEY, last_updated DATETIME2 NULL, last_run_time DATETIME2 NULL
);
GO
INSERT INTO control.fhir_watermark(resource_type,last_updated,last_run_time)
SELECT x.resource_type,NULL,NULL FROM (VALUES ('Patient'),('Encounter'),('Observation'),('Condition')) x(resource_type)
WHERE NOT EXISTS (SELECT 1 FROM control.fhir_watermark w WHERE w.resource_type=x.resource_type);
GO
