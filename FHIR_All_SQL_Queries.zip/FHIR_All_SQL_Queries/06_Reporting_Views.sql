-- Reporting views, reconstructed from the fields described during assessment.
CREATE OR ALTER VIEW dbo.vw_Patient_Summary AS
SELECT p.patient_id,p.family_name,p.given_name,p.gender,p.birth_date,p.last_updated,
 (SELECT COUNT(*) FROM silver.Encounter e WHERE e.patient_id=p.patient_id) AS encounter_count,
 (SELECT COUNT(*) FROM silver.Observation o WHERE o.patient_id=p.patient_id) AS observation_count,
 (SELECT COUNT(*) FROM silver.Condition c WHERE c.patient_id=p.patient_id) AS condition_count
FROM silver.Patient p;
GO
CREATE OR ALTER VIEW dbo.vw_Encounter_Summary AS
SELECT e.encounter_id,e.patient_id,p.family_name,p.given_name,e.status,e.encounter_class,
 e.start_date,e.end_date,e.last_updated
FROM silver.Encounter e LEFT JOIN silver.Patient p ON p.patient_id=e.patient_id;
GO
CREATE OR ALTER VIEW dbo.vw_Observation_Summary AS
SELECT o.observation_id,o.patient_id,o.encounter_id,o.status,o.observation_code,
 o.observation_name,o.observation_value,o.observation_unit,o.effective_date,o.last_updated
FROM silver.Observation o;
GO
CREATE OR ALTER VIEW dbo.vw_Condition_Summary AS
SELECT c.condition_id,c.patient_id,c.encounter_id,c.clinical_status,c.condition_code,
 c.condition_name,c.onset_date,c.recorded_date,c.last_updated
FROM silver.Condition c;
GO
