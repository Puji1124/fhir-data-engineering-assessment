-- Queries used to inspect the resource counts and ensure Patient ID uniqueness.
SELECT 'Patient' AS Resource, COUNT(*) AS Total FROM silver.Patient
UNION ALL SELECT 'Encounter', COUNT(*) FROM silver.Encounter
UNION ALL SELECT 'Observation', COUNT(*) FROM silver.Observation
UNION ALL SELECT 'Condition', COUNT(*) FROM silver.Condition;
GO
SELECT patient_id, COUNT(*) AS duplicate_count
FROM silver.Patient GROUP BY patient_id HAVING COUNT(*) > 1;
GO
-- Inspect raw FHIR Bundle staging by resource.
SELECT resource_type, COUNT(*) AS total_bundles
FROM staging.fhir_raw GROUP BY resource_type;
GO
-- Inspect current and historical Patient versions.
SELECT patient_id, family_name, effective_from, effective_to, is_current
FROM silver.Patient_History ORDER BY patient_id, effective_from;
GO
-- Watermark values and last successful update times.
SELECT * FROM control.fhir_watermark ORDER BY resource_type;
GO
-- Reporting view sample queries.
SELECT TOP (20) * FROM dbo.vw_Patient_Summary;
SELECT TOP (20) * FROM dbo.vw_Encounter_Summary;
SELECT TOP (20) * FROM dbo.vw_Observation_Summary;
SELECT TOP (20) * FROM dbo.vw_Condition_Summary;
