FHIR Assessment SQL - consolidated submission package

01 Schemas and tables
02 Raw staging insert stored procedure
03 Silver upsert procedures: Patient, Encounter, Observation, Condition
04 Patient SCD Type 2 stored procedure
05 Watermark and common resource processor
06 Reporting views
07 Final validation queries
08 Execution commands for upserts (including commands shown in conversation)
09 Additional validation and inspection queries

IMPORTANT PROVENANCE: 01-07 are reconstructed from the assessment conversation and earlier generated SQL package, NOT database-exported exact historical SQL. 08 includes confirmed execution commands; 09 includes confirmed count and duplicate-check queries plus other useful inspection queries. Do not claim these are a word-for-word audit of every historical Query Editor execution.

These are submission reference scripts. DO NOT run the full set on your populated database. Verify definitions against the actual SQL database before submitting. Current confirmed Silver counts: Patient 30, Encounter 15, Observation 15, Condition 15. Patient duplicate-ID query returned no rows.
