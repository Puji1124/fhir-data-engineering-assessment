CREATE OR ALTER PROCEDURE staging.usp_insert_fhir_raw
 @resource_type VARCHAR(50), @raw_json NVARCHAR(MAX),
 @api_url_or_params NVARCHAR(2000)=NULL, @source_file NVARCHAR(1000)=NULL,
 @pipeline_run_id VARCHAR(100)=NULL
AS
BEGIN
 SET NOCOUNT ON;
 IF ISJSON(@raw_json) <> 1 THROW 50001, 'Invalid FHIR JSON', 1;
 INSERT INTO staging.fhir_raw(resource_type,raw_json,api_url_or_params,source_file,pipeline_run_id)
 VALUES (@resource_type,@raw_json,@api_url_or_params,@source_file,@pipeline_run_id);
END;
GO
